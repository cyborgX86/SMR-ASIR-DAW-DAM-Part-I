#! /usr/bin/python
# -*- coding: utf-8-*-
# Obrir els pdf i jpeg adjunts d'un missatge mime
# 27/01/2012
# @edt
# -------------------------------------------------------------------
# Crear un programa Python que envia correu multipart i que recorre
# les diverses parts d’un correu usant la biblioteca mime de Python.
# ioc-m08-uf3-a1 smtp
# -------------------------------------------------------------------
import sys, mailbox, email, mimetypes, subprocess

def desar_pdf(part,n):
    print "desant pdf"
    file = "./attach-%d%s" % (n, ".pdf")    
    fit = open (file, "wb")
    fit.write(part.get_payload(decode=True))
    fit.close()
    popen = subprocess.Popen(["/usr/bin/evince",file])

def desar_jpeg(part,n):
    print "desant jpeg"
    file = "./attach-%d%s" % (n, ".jpeg")  
    fit = open (file, "wb")
    fit.write(part.get_payload(decode=True))
    fit.close()
    popen = subprocess.Popen(["/usr/bin/firefox",file])

nomFitxer = 'pere.mbox1'
bustia = mailbox.mbox(nomFitxer)
numMissatges = bustia.__len__()
# message<---email.message_from_string(string)

# Iterar per a cada missatge
n = 0
for num in range(numMissatges):
    # processar el  missatge 
    msg = bustia.get_message(num)  
    # iterar per les parts del missatges    
    for part in msg.walk():
        main = part.get_content_maintype()
        sub = part.get_content_subtype()
        tipus = part.get_content_type()
        print mimetypes.guess_extension(tipus)
        if sub == "pdf":
            n = n + 1
            desar_pdf(part,n)
        if sub == "jpeg":
            n = n + 1
            desar_jpeg(part,n)
    print
bustia.close()
sys.exit(0)


