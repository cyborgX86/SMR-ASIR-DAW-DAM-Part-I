#! /usr/bin/python
# -*- coding: utf-8-*-
# imitar una conversa telnet smtp amb sockets
# 27/01/2012
# @edt
# -------------------------------------------------------------------
# Crear un programa que envia una carta (un document de text extern 
# en un fitxer) a una llista de destinataris (llista externa en un
# altre fitxer de text). Cal usar la biblioteca de Python smtplib.
# ioc-m08-uf3-a1 smtp
# -------------------------------------------------------------------
import smtplib, sys

try:
    fusuarios = open('usuaris.txt','r')
    fmensaje = open('missatge.txt','r')
except:
    print "No es poden llegir els fitxers"
    sys.exit(0)

# Obtenir el missatge a enviar
mensaje = fmensaje.read()
# Adreça origen
de = raw_input("From: ") 
for email in fusuarios:
    to = email
    server = smtplib.SMTP('localhost')
    server.sendmail(de, to, mensaje)
server.quit()

