#! /usr/bin/python
# -*- coding: utf-8-*-
# imitar una conversa telnet smtp amb sockets
# 27/01/2012
# @edt
# -------------------------------------------------------------------
# Crear un programa que envia un email imitant una sessió telnet a
# un servidor SMTP.
# ioc-m08-uf3-a1 smtp
# -------------------------------------------------------------------
import socket

mfrom="MAIL FROM: unknown@kaos.sex\n"
to_01="RCPT TO: pere\n"
to_02="RCPT TO: root@localhost.localdomain\n"
to_03="RCPT TO: batman@gotham.city\n"

capcaleres="""\
subject: missatge de prova per imitar conversa smtp
Date: Fri, 27 Jan 2012 09:54:15 +0100

From: barakObama@whitehouse.us"""
crlf="\n"
text="""\
aquest és un missatge de prova enviat per unknown, verificar
si realment el from és aquest o en Barak.
Els destinataris són: pere, root i batman.
bye bye
.\n"""

to=to_01+to_02+to_02
msg=capcaleres+crlf+text

print mfrom
print to
print msg

HOST = ''
PORT = 25
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
data = s.recv(1024)
print data

s.send('EHLO localhost.localdomain\n')
data = s.recv(1024)
print data

s.send(mfrom)
data = s.recv(1024)
print data

s.send(to)
data = s.recv(1024)
print data

s.send('DATA\n')
data = s.recv(1024)
print data

s.send(msg)
data = s.recv(1024)
print data

s.close()
print s

